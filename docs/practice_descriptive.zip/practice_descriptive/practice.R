
# import data -------------------------------------------------------------

cmTbmData <- read.csv("~/Dropbox/Workspace/Course/EIU_STAT401/materials/note_slide_04/practice_descriptive/cmTbmData.csv")


# summarise age, csfwcc, sex ----------------------------------------------

install.packages("Hmisc")

library(Hmisc)

## patient group
describe(cmTbmData$groupLong)

## age
### overall
describe(cmTbmData$age)
### by patient group
by(cmTbmData$age, cmTbmData$groupLong, describe)


# factorize sex -----------------------------------------------------------

cmTbmData$sex2 <- factor(cmTbmData$sex, levels = c(1, 2), labels = c("A", "B"))


# using median & quartiles ------------------------------------------------

quantile(cmTbmData$age, na.rm = TRUE)


# figures -----------------------------------------------------------------

## histogram
hist(cmTbmData$age)

### change number of bins
?hist
hist(cmTbmData$age, breaks = 10)
hist(cmTbmData$age, breaks = 5)

## boxplot
boxplot(cmTbmData$age)

### boxplot by patient groups
boxplot(age ~ groupLong, data = cmTbmData)


